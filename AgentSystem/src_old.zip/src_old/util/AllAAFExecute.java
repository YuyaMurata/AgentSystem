/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.IOException;

/**
 *
 * @author 悠也
 */
public class AllAAFExecute {
    public static void main(String[] args) throws IOException {
        AllResultsExecute.main(null);
        
        AllAnalisysExecute.main(null);
    }
}
