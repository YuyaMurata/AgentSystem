clsql -user:cetaadmin -password:cetaadmin
