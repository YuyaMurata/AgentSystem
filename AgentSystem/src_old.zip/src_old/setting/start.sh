startCatalog &&
startServer s0 s1 a0 a1
