stopCluster -force -user:cetaadmin -password:cetaadmin &&
stopCatalog
